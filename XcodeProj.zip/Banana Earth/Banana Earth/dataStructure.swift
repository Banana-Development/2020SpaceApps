//
//  dataStructure.swift
//  Banana Earth
//
//  Created by Wongkraiwich Chuenchomphu on 10/2/20.
//

import Foundation // i have no idea what is Foundation Lol// MARK: - Todo

struct Todo: Codable {
    let userID, id: String
    let fuel_type_code: String
    let station_name: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, fuel_type_code, station_name
    }
}
