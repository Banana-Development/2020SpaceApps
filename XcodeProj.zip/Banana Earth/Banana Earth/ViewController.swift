//
//  ViewController.swift
//  Banana Earth
//
//  Created by Wongkraiwich Chuenchomphu on 10/2/20.
//
//

import UIKit
import WebKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var searchBox: UITextField!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var worldView: UIButton!
    
    
    var player = AVAudioPlayer()
    
    var pickerData: [String] = [String]()

        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
            
            let path = Bundle.main.path(forResource: "Click", ofType: "wav")
            let url = URL(fileURLWithPath: path!)
            do {
                player = try AVAudioPlayer(contentsOf: url)
                player.prepareToPlay()
            } catch {
                print("playing click sound error")
            }
            
        }

    @IBAction func searchPressed(_ sender: Any) {
        player.play()
        let filter = String(searchBox.text ?? "nil")
        print(searchBox.text)
        let stringurl = String("https://data.cityofchicago.org/resource/f7f2-ggz5.json?id=\(filter)")
        let url = (URL(string: "https://data.cityofchicago.org/resource/f7f2-ggz5.json?id=\(filter)") ?? URL(string: "https://data.cityofchicago.org/resource/f7f2-ggz5.json?"))!
        let urlRequest = URLRequest(url: url)
        self.webView.customUserAgent = String("Mozilla/5.0 (Macintosh; Intel Mac OS X 11_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15")
        self.webView.load(urlRequest)
    }
    @IBAction func worldViewPressed(_ sender: Any) {
        player.play()
        self.webView.customUserAgent = String("Mozilla/5.0 (Macintosh; Intel Mac OS X 11_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15")
        let url = URL(string: "https://worldview.earthdata.nasa.gov")
        let re = URLRequest(url: url!)
        self.webView.load(re)
    }
    
}

