//
//  ViewController.swift
//  Banana Earth
//
//  Created by Wongkraiwich Chuenchomphu on 10/2/20.
//
//

import UIKit

class ViewController: UIViewController {
    let jsonAPILink = URL(string: "https://data.cityofchicago.org/resource/f7f2-ggz5.json?station_name=AmeriGas")
    var filter = String("")

    @IBOutlet weak var titleLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        func fetchData() {
                let urlString = String("https://data.cityofchicago.org/resource/f7f2-ggz5.json?" + filter)
                guard let url = URL(string: urlString) else {return}
                URLSession.shared.dataTask(with: url) { (data, res, error) in
            
                    do {
                        let todoDetails = try JSONDecoder().decode(Todo.self, from: data!)
                        DispatchQueue.main.async {
                            self.titleLable.text = String("id: " + todoDetails.id + todoDetails.fuel_type_code + todoDetails.station_name)
                        }
                    } catch {}
                }.resume()
            }
        fetchData()

        
    }


}

